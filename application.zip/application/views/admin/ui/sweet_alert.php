 <!-- .row -->
                <div class="row">
                    <div class="col-lg-3 col-xs-12">
                        <div class="white-box">
                            <h3 class="box-title">A basic message <small>(Click on image)</small> </h3>
                            <img src="<?php echo base_url(); ?>optimum/plugins/images/alert.png" alt="alert" class="img-responsive model_img" id="sa-basic"> </div>
                    </div>
                    <div class="col-lg-3 col-xs-12">
                        <div class="white-box">
                            <h3 class="box-title">Title with a text under <small>(Click on image)</small></h3>
                            <img src="<?php echo base_url(); ?>optimum/plugins/images/alert2.png" alt="alert" class="img-responsive model_img" id="sa-title"> </div>
                    </div>
                    <div class="col-lg-3 col-xs-12">
                        <div class="white-box">
                            <h3 class="box-title">Success Message <small>(Click on image)</small></h3>
                            <img src="<?php echo base_url(); ?>optimum/plugins/images/alert3.png" alt="alert" class="img-responsive model_img" id="sa-success"> </div>
                    </div>
                    <div class="col-lg-3 col-xs-12">
                        <div class="white-box">
                            <h3 class="box-title">Warning message <small>(Click on image)</small></h3>
                            <img src="<?php echo base_url(); ?>optimum/plugins/images/alert4.png" alt="alert" class="img-responsive model_img" id="sa-warning"> </div>
                    </div>
                </div>
                <!-- /.row -->
                <!-- .row -->
                <div class="row">
                    <div class="col-lg-4 col-xs-12">
                        <div class="white-box">
                            <h3 class="box-title">A basic message <small>(Click on image)</small></h3>
                            <img src="<?php echo base_url(); ?>optimum/plugins/images/alert5.png" alt="alert" class="img-responsive model_img" id="sa-params"></div>
                    </div>
                    <div class="col-lg-4 col-xs-12">
                        <div class="white-box">
                            <h3 class="box-title">Alert with Image <small>(Click on image)</small></h3>
                            <img src="<?php echo base_url(); ?>optimum/plugins/images/alert7.png" alt="alert" class="img-responsive model_img" id="sa-image"> </div>
                    </div>
                    <div class="col-lg-4 col-xs-12">
                        <div class="white-box">
                            <h3 class="box-title">Alert with time <small>(Click on image)</small></h3>
                            <img src="<?php echo base_url(); ?>optimum/plugins/images/alert6.png" alt="alert" class="img-responsive model_img" id="sa-close"> </div>
                    </div>
                </div>
                <!-- /.row -->