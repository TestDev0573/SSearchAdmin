            <footer class="footer text-center"><i class="fa fa-globe"></i> B and S Footer<?php // echo $footer;?>&nbsp; <i class="fa fa-globe"></i> </footer>
