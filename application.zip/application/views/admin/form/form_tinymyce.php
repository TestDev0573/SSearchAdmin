  <!-- .row -->
                <div class="row">
                    <div class="col-sm-12">
                        <div class="white-box">
                            <h3 class="box-title m-b-0">Tinymce wysihtml5</h3>
                            <p class="text-muted m-b-30">Bootstrap html5 editor</p>
                            <form method="post">
                                <textarea id="mymce" name="area"></textarea>
                            </form>
                        </div>
                    </div>
                </div>
                <!-- /.row -->