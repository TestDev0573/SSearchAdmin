 <!-- .row -->
                <div class="row">
                    <div class="col-sm-12">
                        <div class="white-box">
                            <h3 class="box-title m-b-0">Bootstrap wysihtml5</h3>
                            <p class="text-muted m-b-30">Bootstrap html5 editor</p>
                            <form method="post">
                                <div class="form-group">
                                    <textarea class="textarea_editor form-control" rows="15" placeholder="Enter text ..."></textarea>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <!-- /.row -->